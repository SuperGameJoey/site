var MyLayer = cc.Layer.extend({

    ctor:function ()
    {
        this._super();
        // GAME CODE STARTS
        var winSize = cc.Director.getInstance().getWinSize();

        var bgColor = new cc.Color4B(255, 128, 0, 255);
        var bgLayer = cc.LayerColor.create(bgColor, winSize.width, winSize.height);
        this.addChild(bgLayer);

        var titleLbl = cc.LabelTTF.create("Scene Switcher", "Helvetica", 64);
        titleLbl.setPosition(cc.p(winSize.width/2, winSize.height/2));
        this.addChild(titleLbl);

        var easyLbl = cc.LabelTTF.create("Easy", "Helvetica", 32);
        var easyItm = cc.MenuItemLabel.create(easyLbl, this.startEasy);
        var startMenu = cc.Menu.create(easyItm);
        this.addChild(startMenu);

        startMenu.setPosition(cc.p(winSize.width/2, winSize.height/4));
    },

    startEasy:function ()
    {
        console.log("START EASY!!");
        var myGameScene = new GameScene();
        cc.Director.getInstance().replaceScene(myGameScene);
    }
    
});

var GameScene = cc.Scene.extend({
    ctor:function ()
    {
        this._super();
        var myGameLayer = new GameLayer();
        this.addChild(myGameLayer);
    }
});

var GameLayer = cc.Layer.extend({
    ctor:function ()
    {
        this._super();
        console.log("You made a new GameLayer! YAY!");
    }
});

var MyScene = cc.Scene.extend({

    ctor:function ()
    {
        this._super();
        var layer = new MyLayer();
        this.addChild(layer);
    }

});