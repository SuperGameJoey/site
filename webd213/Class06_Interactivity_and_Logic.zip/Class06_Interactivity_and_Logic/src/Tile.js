var Tile = cc.Sprite.extend({
	faceSpriteName:null,
	tileRow:0,
	tileColumn:0,
	isFaceUp:false,

	ctor:function(sprName) {
		this._super();
		console.log("created new Tile");
		this.faceSpriteName = sprName;
		this.initWithSpriteFrameName("CardBack.png");
	},

	showFace:function() {
		console.log("Show Tile Face");
		var frame = cc.SpriteFrameCache.getInstance().getSpriteFrame(this.faceSpriteName);
		this.setDisplayFrame(frame);
		isFaceUp = true;
	},

	showBack:function() {
		console.log("Show Tile Back");
		var frame = cc.SpriteFrameCache.getInstance().getSpriteFrame("CardBack.png");
		this.setDisplayFrame(frame);
		isFaceUp = false;
	}
});

/*
var heartShapedCookie = cookie.extend({
	ctor:function(color) {
		this.color = color;
	}
});

var pinkHeartCookie = new heartShapedCookie("pink");

cookie
|
Heart shaped cookie
|
Pink heartshaped cookie
*/