// var s_ImageName = "ImageFileName.png";
// var s_Image2Name = "Image2FileName.png";

var s_CardBack = "CardBack.png";

var p_Heroes = "Spritesheet.plist";
var s_Heroes = "Spritesheet.png";

var g_resources = [
    //image
    //{src:s_ImageName},
    //{src:s_Image2Name}
    {src:s_CardBack},
    {src:s_Heroes},

    //plist
    {src:p_Heroes}

    //fnt

    //tmx

    //bgm

    //effect
];