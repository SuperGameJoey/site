var GameLayer = cc.Layer.extend({

    ctor:function ()
    {
        this._super();
        console.log("Game Started!");
        // entry point to layer
    }
    
});

var GameScene = cc.Scene.extend({

    ctor:function ()
    {
        this._super();
        var layer = new GameLayer();
        this.addChild(layer);
    }

});