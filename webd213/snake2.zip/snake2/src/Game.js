var GameLayer = cc.Layer.extend({
    _scoreLbl:null,

    ctor:function ()
    {
        this._super();
        console.log("Game Started!");
        
        var winSize = cc.Director.getInstance().getWinSize();

        this._scoreLbl = cc.LabelTTF.create("Score", "Krungthep", 30);
        this._scoreLbl.setColor(new cc.Color4B(54,56,27,255));
        this._scoreLbl.setPosition(cc.p(70, winSize.height - 30));
        this.addChild(this._scoreLbl);
    }
    
});

var GameScene = cc.Scene.extend({

    ctor:function ()
    {
        this._super();
        var layer = new GameLayer();
        this.addChild(layer);
    }

});