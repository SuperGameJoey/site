1)	Get boilerplate and images from lapegna.com/webd213

2)	Add plist and png to the resources
	* copy to res folder
	* reference in src/resource.js

3)	Add a background of RGB (174, 206, 139)
		* cc.Director.getInstance().getWinSize()
		* new cc.Color4B(r, g, b, a)
        * cc.LayerColor.create(color, width, height)

4)	Setup a SpriteFrameCache for the graphics
		* cc.SpriteFrameCache.getInstance().addSpriteFrames(plist);

5)	Create a new JavaScript file that holds the gameplay (Game.js)
		* will contain a GameScene and a GameLayer



* Remember the structure of a Class

var heartShapedCookie = cookie.extend({
	glutenFree: false,
	vegan: false,
	delicious: true,
	color: null,

	ctor:function(color) {
		this.color = color;
	},

	eatCookiefunction:function() {
		console.log("YUM!!");
	}
});
