var s_Snake = "Snake.png";
var p_Snake = "Snake.plist";

var g_resources = [
    {src:s_Snake},
    {src:p_Snake}
];