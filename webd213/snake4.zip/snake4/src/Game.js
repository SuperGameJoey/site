var GameLayer = cc.Layer.extend({
    _scoreLbl:null,
    _spriteBatch:null,
    _snake:[], // all the positions of each sname segment
    _snakeSprites:[], // all the sprites for each snake segment
    _maxRows:0,
    _maxCols:0,
    _gridSize:32,
    _speed:0.5,
    _t:0, // hold the time since the last snake movement
    _direction:0, // RIGHT = 0; DOWN = 1; LEFT = 2; UP = 3

    ctor:function ()
    {
        this._super();
        console.log("Game Started!");
        
        var winSize = cc.Director.getInstance().getWinSize();

        this._maxCols = Math.floor(winSize.width / this._gridSize);
        this._maxRows = Math.floor(winSize.height / this._gridSize);

        var bgLayer = cc.LayerColor.create(new cc.Color4B(174, 206, 139, 255),
                                            winSize.width,
                                            winSize.height);
        this.addChild(bgLayer);

        this._scoreLbl = cc.LabelTTF.create("Score", "Krungthep", 30);
        this._scoreLbl.setColor(new cc.Color4B(54,56,27,255));
        this._scoreLbl.setPosition(cc.p(70, winSize.height - 30));
        this.addChild(this._scoreLbl);

        this._spriteBatch = cc.SpriteBatchNode.create(s_Snake);
        this.addChild(this._spriteBatch);

        this._snake[0] = cc.p(Math.floor(this._maxCols/2), Math.floor(this._maxRows/2));
        this._snakeSprites[0] = cc.Sprite.createWithSpriteFrameName("snake-head.png");        
        this._spriteBatch.addChild(this._snakeSprites[0]);

        this.addSnakePiece();
        this.addSnakePiece();
        this.addSnakePiece();
        this.addSnakePiece();
        this.addSnakePiece();
        this.addSnakePiece();
        this.addSnakePiece();

        this.scheduleUpdate();

        if (sys.capabilities.hasOwnProperty('keyboard')) {
            this.setKeyboardEnabled(true);
        }
    },

    addSnakePiece:function() {
        var n = this._snake.length; // next piece index
        var last = this._snake[n - 1];

        this._snake[n] = cc.p(last.x, last.y);
        this._snakeSprites[n] = cc.Sprite.createWithSpriteFrameName("snake-body.png");
        this._spriteBatch.addChild(this._snakeSprites[n]);
    },

    onKeyUp:function(key) {
        switch(key) {
            case cc.KEY.right:
                this._direction = 0;
                break;
            case cc.KEY.down:
                this._direction = 1;
                break;
            case cc.KEY.left:
                this._direction = 2;
                break;
            case cc.KEY.up:
                this._direction = 3;
                break;
        }
    },

    update:function (dt) {

        this._t += dt;

        if (this._t >= this._speed) {
            this._t = 0;
            this.moveSnake();
        }
    },

    moveSnake:function() {
        // [0, 1, 2, 3]
        // for each snake piece from the back
            // set the snake piece to be in the same position as the one before it (i - 1)

        for (var i = this._snake.length - 1; i > 0; i--) {
            this._snake[i].x = this._snake[i - 1].x;
            this._snake[i].y = this._snake[i - 1].y;

            var piece = this._snake[i];
            var sprite = this._snakeSprites[i];

            sprite.setPosition(cc.p(piece.x * this._gridSize, piece.y * this._gridSize));
        }

        switch(this._direction) {
            case 0: // MOVE RIGHT
                this._snake[0].x++;
                break;
            case 1: // DOWN
                this._snake[0].y--;
                break;
            case 2: // LEFT
                this._snake[0].x--;
                break;
            case 3: // UP
                this._snake[0].y++;
                break;
            default:
                console.warn("ERROR: Direction must be 0, 1, 2 or 3");
                break;
        }

        var xPos = this._snake[0].x * this._gridSize;
        var yPos = this._snake[0].y * this._gridSize;
        
        this._snakeSprites[0].setPosition(xPos, yPos);
        this._snakeSprites[0].setRotation(this._direction * 90);
    }
    
});

var GameScene = cc.Scene.extend({

    ctor:function ()
    {
        this._super();
        var layer = new GameLayer();
        this.addChild(layer);
    }

});