var MyLayer = cc.Layer.extend({

    ctor:function ()
    {
        this._super();
        var winSize = cc.Director.getInstance().getWinSize();

        var bgColor = new cc.Color4B(174, 206, 139, 255);
        var bgLayer = cc.LayerColor.create(bgColor, winSize.width, winSize.height);
        this.addChild(bgLayer);

        cc.SpriteFrameCache.getInstance().addSpriteFrames(p_Snake);

        var playBtn = cc.MenuItemSprite.create(cc.Sprite.createWithSpriteFrameName("btn-play-off.png"),
                                               cc.Sprite.createWithSpriteFrameName("btn-play-on.png"),
                                               this.playGame,
                                               this);
        var menu = cc.Menu.create(playBtn);
        this.addChild(menu);
        menu.alignItemsVertically();

    },

    playGame:function()
    {
        var gameScene = new GameScene();
        cc.Director.getInstance().replaceScene(
            cc.TransitionTurnOffTiles.create(0.5, gameScene));
    }
    
});

var MyScene = cc.Scene.extend({

    ctor:function ()
    {
        this._super();
        var layer = new MyLayer();
        this.addChild(layer);
    }

});