/**
 * Created with JetBrains WebStorm.
 * User: Administrator
 * Date: 13-6-20
 * Time: 下午3:54
 * To change this template use File | Settings | File Templates.
 */

cc.PhysicsWorld = cc.Class.extend({
    BoneColliderSignal:[],
    _noGravityWorld:null,
    _contactListener:null,
    _debugDraw:null,
    ctor:function () {

    },
    initNoGravityWorld:function () {

    },
    update:function () {

    },
    drawDebug:function () {

    },
    getNoGravityWorld:function () {

    }
});
cc.PhysicsWorld.getInstance = function () {

};
cc.PhysicsWorld.purge = function () {

};