// var s_ImageName = "ImageFileName.png";
// var s_Image2Name = "Image2FileName.png";

var s_CardBack = "CardBack.png";

var g_resources = [
    //image
    //{src:s_ImageName},
    //{src:s_Image2Name}
    {src:s_CardBack}

    //plist

    //fnt

    //tmx

    //bgm

    //effect
];