var GameScene = cc.Scene.extend({
    ctor:function (difficultyStr)
    {
        this._super();
        var myGameLayer = new GameLayer(difficultyStr);
        this.addChild(myGameLayer);
    }
});

var GameLayer = cc.Layer.extend({
    ctor:function (difficultyStr)
    {
        this._super();
        console.log("You made a new GameLayer! YAY!");

        var winSize = cc.Director.getInstance().getWinSize();
        var backLbl = cc.LabelTTF.create("Exit", "Helvetica", 32);
        var backItm = cc.MenuItemLabel.create(backLbl, this.showMenu);
        var backMenu = cc.Menu.create(backItm);
        this.addChild(backMenu);

        backItm.setAnchorPoint(cc.p(1, 0));
        backMenu.setPosition(cc.p(winSize.width - 40, 40));

        var diffLbl = cc.LabelTTF.create(difficultyStr, "Helvetica", 64);
        diffLbl.setPosition(cc.p(winSize.width/2, winSize.height/2));
        this.addChild(diffLbl);

        var card = cc.Sprite.create(s_CardBack);
        card.setPosition(cc.p(card.getContentSize().width/2, winSize.height - card.getContentSize().height/2));
        this.addChild(card);

    },

    showMenu:function ()
    {
        var menuScene = new MyScene();
        cc.Director.getInstance().replaceScene(menuScene);
    }


});