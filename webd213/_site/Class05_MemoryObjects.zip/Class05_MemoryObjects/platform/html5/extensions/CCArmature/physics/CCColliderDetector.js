/**
 * Created with JetBrains WebStorm.
 * User: Administrator
 * Date: 13-6-20
 * Time: 下午3:57
 * To change this template use File | Settings | File Templates.
 */
cc.ColliderBody = cc.Class.extend({
    _b2b:null,
    _contourData:null,
    ctor:function () {

    },
    getB2Body:function () {

    },
    getContourData:function () {

    }
});
cc.ColliderDetector = cc.Class.extend({
    _colliderBodyList:null,
    _bone:null,
    ctor:function () {

    },
    init:function (bone) {
    },
    addContourData:function (contourData) {
    },
    addContourDataList:function (contourDataList) {
    },
    removeContourData:function (contourData) {
    },
    removeAll:function () {
    },
    updateTransform:function (t) {
    },
    setColliderFilter:function (filter) {
    },
    setActive:function (active) {
    }
});
cc.ColliderDetector.create = function () {

};