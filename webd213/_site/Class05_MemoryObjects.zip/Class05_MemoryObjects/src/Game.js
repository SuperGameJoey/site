var GameScene = cc.Scene.extend({
    ctor:function (rows, columns)
    {
        this._super();
        var myGameLayer = new GameLayer(rows, columns);
        this.addChild(myGameLayer);
    }
});

var GameLayer = cc.Layer.extend({
    ctor:function (rows, columns)
    {
        this._super();
        console.log("You made a new GameLayer! YAY!");

        var winSize = cc.Director.getInstance().getWinSize();

        cc.SpriteFrameCache.getInstance().addSpriteFrames(p_Heroes);
        var spriteBatch = cc.SpriteBatchNode.create(s_Heroes);

        var maxTiles = (rows * columns) / 2;

        // contain tiles to be placed
        var tilesAvailable = new Array();
        // contains all the tiles on screen
        var tilesInPlay = new Array();
        // player selected tiles - won't have more 2
        var tilesSelected = new Array();
        var tilePadding = 10;

        for (t = 1; t <= maxTiles; t++) {
            for (i = 1; i <= 2; i++) {
                //var tileSpr = cc.Sprite.createWithSpriteFrameName("tile" + t + ".jpg");
                var tileSpr = new Tile("tile" + t + ".jpg");
                tileSpr.setAnchorPoint(0,0);
                tilesAvailable.push(tileSpr);
            }
        }

        var tileSize = tilesAvailable[0].getContentSize();
        console.log("Created " + tilesAvailable.length + " Sprites");

        var tilesLayer = cc.Layer.create();
        tilesLayer.setAnchorPoint(0,0);
        this.addChild(tilesLayer);

        var tilesWidth = (tileSize.width * columns) + (tilePadding * (columns - 1));
        var tilesHeight = (tileSize.height * rows) + (tilePadding * (rows - 1));
        tilesLayer.setPosition(cc.p((winSize.width-tilesWidth)/2, (winSize.height - tilesHeight)/2));

        tilesLayer.addChild(spriteBatch);

        // draw sprites to screen
        for (row = 0; row < rows; row++) {
            for (col = 0; col < columns; col++) {
                var randNum = Math.floor(Math.random()*tilesAvailable.length);
                var tileSpr = tilesAvailable.splice(randNum, 1)[0];

                var xPos = col * (tileSize.width + tilePadding);
                var yPos = row * (tileSize.height + tilePadding);

                tileSpr.setPosition(cc.p(xPos, yPos));
                spriteBatch.addChild(tileSpr);

                tilesInPlay.push(tileSpr);

                tileSpr.showBack();
            }
        }

        var backLbl = cc.LabelTTF.create("Exit", "Helvetica", 32);
        var backItm = cc.MenuItemLabel.create(backLbl, this.showMenu);
        var backMenu = cc.Menu.create(backItm);
        this.addChild(backMenu);

        backItm.setAnchorPoint(cc.p(1, 0));
        backMenu.setPosition(cc.p(winSize.width - 40, 40));


    },

    showMenu:function ()
    {
        var menuScene = new MyScene();
        cc.Director.getInstance().replaceScene(menuScene);
    }


});