var MyLayer = cc.Layer.extend({

    ctor:function ()
    {
        this._super();
        // GAME CODE STARTS
    }
    
});

var MyScene = cc.Scene.extend({

    ctor:function ()
    {
        this._super();
        var layer = new MyLayer();
        this.addChild(layer);
    }

});